import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Vercel doesn't need 'standalone' output — it handles the build automatically
  // output: "standalone",  // Removed for Vercel compatibility

  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,

  // Allow images from external sources (for Google avatars, etc.)
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "lh3.googleusercontent.com" },
      { protocol: "https", hostname: "avatars.githubusercontent.com" },
    ],
  },
};

export default nextConfig;
