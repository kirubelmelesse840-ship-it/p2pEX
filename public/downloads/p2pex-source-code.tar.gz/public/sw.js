// P2PEX Service Worker — handles web push notifications
self.addEventListener('install', (event) => {
  console.log('[SW] Installed')
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  console.log('[SW] Activated')
  event.waitUntil(self.clients.claim())
})

self.addEventListener('push', (event) => {
  console.log('[SW] Push received:', event)
  let payload = {}
  try {
    payload = event.data ? event.data.json() : {}
  } catch (e) {
    payload = { title: 'P2PEX', body: event.data ? event.data.text() : 'New notification' }
  }
  const {
    title = 'P2PEX Notification',
    body = 'You have a new update',
    url = '/',
    icon = '/logo.png',
    badge = '/logo.png',
    tag = 'p2pex-notification',
    timestamp = Date.now(),
  } = payload
  const options = { body, icon, badge, tag, data: { url, timestamp }, requireInteraction: false, vibrate: [100, 50, 100] }
  event.waitUntil(self.registration.showNotification(title, options))
})

self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification clicked:', event)
  event.notification.close()
  const targetUrl = event.notification.data?.url || '/'
  event.waitUntil(
    (async () => {
      const allClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      for (const client of allClients) {
        if ('focus' in client) {
          try {
            await client.focus()
            if ('navigate' in client) await client.navigate(targetUrl)
            return
          } catch (e) { console.error('[SW] Failed to focus client:', e) }
        }
      }
      if (self.clients.openWindow) {
        try { await self.clients.openWindow(targetUrl) } catch (e) { console.error('[SW] Failed to open window:', e) }
      }
    })()
  )
})

self.addEventListener('pushsubscriptionchange', (event) => {
  console.log('[SW] Push subscription changed')
  event.waitUntil(
    (async () => {
      try {
        const registration = await self.registration
        const newSubscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: await getVapidKey(),
        })
        const allClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
        for (const client of allClients) {
          if ('postMessage' in client) {
            client.postMessage({ type: 'PUSH_SUBSCRIPTION_CHANGED', subscription: newSubscription })
          }
        }
      } catch (e) { console.error('[SW] Failed to resubscribe:', e) }
    })()
  )
})

async function getVapidKey() {
  try {
    const res = await fetch('/api/push/subscribe')
    const data = await res.json()
    return urlBase64ToUint8Array(data.publicKey)
  } catch (e) {
    console.error('[SW] Failed to fetch VAPID key:', e)
    return null
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i)
  return outputArray
}
