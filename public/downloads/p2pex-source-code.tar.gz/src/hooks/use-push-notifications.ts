'use client'

import { useState, useEffect, useCallback } from 'react'

interface PushState {
  supported: boolean
  permission: NotificationPermission | 'unsupported'
  subscribed: boolean
  loading: boolean
  error: string | null
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i)
  }
  return outputArray
}

export function usePushNotifications() {
  const [state, setState] = useState<PushState>({
    supported: false,
    permission: 'unsupported',
    subscribed: false,
    loading: false,
    error: null,
  })

  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      setState((s) => ({ ...s, supported: false, permission: 'unsupported' }))
      return
    }
    setState((s) => ({ ...s, supported: true, permission: Notification.permission }))
  }, [])

  useEffect(() => {
    if (!state.supported) return
    let cancelled = false
    ;(async () => {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' })
        console.log('[push] SW registered:', reg.scope)
        if (!cancelled) setState((s) => ({ ...s, error: null }))
      } catch (e: any) {
        console.error('[push] SW registration failed:', e)
        if (!cancelled) setState((s) => ({ ...s, error: e?.message || 'SW registration failed' }))
      }
    })()
    return () => { cancelled = true }
  }, [state.supported])

  const checkSubscription = useCallback(async () => {
    if (!state.supported) return
    try {
      const reg = await navigator.serviceWorker.ready
      const existing = await reg.pushManager.getSubscription()
      setState((s) => ({ ...s, subscribed: !!existing, permission: Notification.permission }))
    } catch (e) {
      console.error('[push] checkSubscription error:', e)
    }
  }, [state.supported])

  useEffect(() => {
    if (state.supported) checkSubscription()
  }, [state.supported, checkSubscription])

  const subscribe = useCallback(async (): Promise<boolean> => {
    if (!state.supported) {
      setState((s) => ({ ...s, error: 'Push notifications are not supported in this browser' }))
      return false
    }
    setState((s) => ({ ...s, loading: true, error: null }))
    try {
      const permission = await Notification.requestPermission()
      setState((s) => ({ ...s, permission }))
      if (permission !== 'granted') {
        setState((s) => ({ ...s, loading: false, subscribed: false, error: 'Permission denied' }))
        return false
      }
      const keyRes = await fetch('/api/push/subscribe')
      const keyData = await keyRes.json()
      if (!keyData.publicKey) throw new Error('Push not configured on server')
      const reg = await navigator.serviceWorker.ready
      const subscription = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(keyData.publicKey),
      })
      const subJSON = subscription.toJSON()
      const subRes = await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: subJSON.endpoint, keys: subJSON.keys }),
      })
      const subData = await subRes.json()
      if (subData.error) throw new Error(subData.error)
      setState((s) => ({ ...s, loading: false, subscribed: true, error: null }))
      return true
    } catch (e: any) {
      console.error('[push] subscribe error:', e)
      setState((s) => ({ ...s, loading: false, error: e?.message || 'Subscription failed' }))
      return false
    }
  }, [state.supported])

  const unsubscribe = useCallback(async (): Promise<boolean> => {
    setState((s) => ({ ...s, loading: true, error: null }))
    try {
      const reg = await navigator.serviceWorker.ready
      const existing = await reg.pushManager.getSubscription()
      if (existing) {
        await existing.unsubscribe()
        await fetch('/api/push/subscribe', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ endpoint: existing.endpoint }),
        })
      }
      setState((s) => ({ ...s, loading: false, subscribed: false }))
      return true
    } catch (e: any) {
      console.error('[push] unsubscribe error:', e)
      setState((s) => ({ ...s, loading: false, error: e?.message || 'Unsubscribe failed' }))
      return false
    }
  }, [])

  return { ...state, subscribe, unsubscribe, refresh: checkSubscription }
}
