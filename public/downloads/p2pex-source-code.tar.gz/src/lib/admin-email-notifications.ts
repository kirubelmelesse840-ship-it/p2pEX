/**
 * Email notifications to admin for various user activities.
 * Uses Ethereal email for development (preview links in console).
 */
import nodemailer from 'nodemailer'

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'kirubelmelesse840@gmail.com'

let transporter: nodemailer.Transporter | null = null

async function getTransporter() {
  if (transporter) return transporter
  // Use Ethereal for dev/test, or configure with real SMTP in production
  const etherealEmail = process.env.ETHEREAL_EMAIL
  const etherealPassword = process.env.ETHEREAL_PASSWORD
  if (etherealEmail && etherealPassword) {
    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      auth: { user: etherealEmail, pass: etherealPassword },
    })
  } else {
    // Generate a test account on the fly
    const testAccount = await nodemailer.createTestAccount()
    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      auth: { user: testAccount.user, pass: testAccount.pass },
    })
  }
  return transporter
}

async function sendEmail(subject: string, text: string, html?: string) {
  try {
    const t = await getTransporter()
    const info = await t.sendMail({
      from: process.env.FROM_EMAIL || 'P2PEX <noreply@p2pex.com>',
      to: ADMIN_EMAIL,
      subject,
      text,
      html: html || text,
    })
    console.log(`[email] Sent: ${subject} — preview: ${nodemailer.getTestMessageUrl(info)}`)
  } catch (e) {
    console.error('[email] Failed to send:', e)
  }
}

export async function notifyAdminUserSignup(userName: string, userEmail: string, userId: string) {
  await sendEmail(
    'New User Signup',
    `New user registered:\n\nName: ${userName}\nEmail: ${userEmail}\nUser ID: ${userId}`,
    `<h2>New User Signup</h2><p><strong>Name:</strong> ${userName}</p><p><strong>Email:</strong> ${userEmail}</p><p><strong>User ID:</strong> ${userId}</p>`
  )
}

export async function notifyAdminKycSubmission(userName: string, userEmail: string, userId: string) {
  await sendEmail(
    'KYC Submission — Review Required',
    `User submitted KYC for review:\n\nName: ${userName}\nEmail: ${userEmail}\nUser ID: ${userId}\n\nPlease review in the admin panel.`,
    `<h2>KYC Submission — Review Required</h2><p><strong>Name:</strong> ${userName}</p><p><strong>Email:</strong> ${userEmail}</p><p><strong>User ID:</strong> ${userId}</p><p>Please review in the admin panel.</p>`
  )
}

export async function notifyAdminP2POrder(buyerName: string, buyerEmail: string, asset: string, amount: number, total: number, currency: string, paymentMethod: string) {
  await sendEmail(
    'New P2P Order — Payment Review Required',
    `New P2P order placed:\n\nBuyer: ${buyerName} (${buyerEmail})\nAsset: ${amount} ${asset}\nTotal: ${total} ${currency}\nPayment Method: ${paymentMethod}\n\nPlease review the payment screenshot in the admin panel.`,
    `<h2>New P2P Order — Payment Review Required</h2><p><strong>Buyer:</strong> ${buyerName} (${buyerEmail})</p><p><strong>Asset:</strong> ${amount} ${asset}</p><p><strong>Total:</strong> ${total} ${currency}</p><p><strong>Payment Method:</strong> ${paymentMethod}</p><p>Please review the payment screenshot in the admin panel.</p>`
  )
}

export async function notifyAdminSupportMessage(userName: string, userEmail: string, userId: string, message: string) {
  await sendEmail(
    'New Support Message',
    `New support message from:\n\nName: ${userName}\nEmail: ${userEmail}\nUser ID: ${userId}\n\nMessage: ${message}`,
    `<h2>New Support Message</h2><p><strong>Name:</strong> ${userName}</p><p><strong>Email:</strong> ${userEmail}</p><p><strong>User ID:</strong> ${userId}</p><p><strong>Message:</strong> ${message}</p>`
  )
}
