/**
 * Web Push notification helper.
 * Sends push notifications to subscribed users across all their devices.
 */
import webpush from 'web-push'
import { db } from '@/lib/db'

// Configure web-push with VAPID keys
const publicKey = process.env.VAPID_PUBLIC_KEY
const privateKey = process.env.VAPID_PRIVATE_KEY
const subject = process.env.VAPID_SUBJECT || 'mailto: supportp2pex.exchange@gmail.com'

if (publicKey && privateKey) {
  webpush.setVapidDetails(subject, publicKey, privateKey)
}

export interface PushPayload {
  title: string
  body: string
  url?: string
  icon?: string
  badge?: string
  tag?: string
}

/**
 * Send a push notification to all subscribed devices of a single user.
 * Silently skips if the user has no subscriptions or push is not configured.
 */
export async function sendPushToUser(userId: string, payload: PushPayload): Promise<void> {
  if (!publicKey || !privateKey) {
    console.warn('[push] VAPID keys not configured — skipping push notification')
    return
  }

  try {
    const subs = await db.pushSubscription.findMany({ where: { userId } })
    if (subs.length === 0) return

    const pushPayload = JSON.stringify({
      title: payload.title,
      body: payload.body,
      url: payload.url || '/',
      icon: payload.icon || '/logo.png',
      badge: payload.badge || '/logo.png',
      tag: payload.tag || 'p2pex-notification',
      timestamp: Date.now(),
    })

    const results = await Promise.allSettled(
      subs.map(async (sub) => {
        try {
          await webpush.sendNotification(
            {
              endpoint: sub.endpoint,
              keys: { p256dh: sub.p256dh, auth: sub.auth },
            },
            pushPayload
          )
        } catch (err: any) {
          // If subscription is no longer valid (410 Gone / 404), remove it
          if (err?.statusCode === 410 || err?.statusCode === 404) {
            try {
              await db.pushSubscription.delete({ where: { id: sub.id } })
              console.log(`[push] Removed expired subscription ${sub.id}`)
            } catch {}
          } else {
            console.error(`[push] Failed to send to ${sub.endpoint.slice(0, 50)}:`, err?.message)
          }
        }
      })
    )

    const succeeded = results.filter(r => r.status === 'fulfilled').length
    console.log(`[push] Sent to ${succeeded}/${subs.length} devices for user ${userId}: ${payload.title}`)
  } catch (e: any) {
    console.error('[push] sendPushToUser error:', e?.message)
  }
}

/**
 * Convenience helpers for common notification scenarios
 */
export async function notifyUserDepositApproved(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '✅ Deposit Approved',
    body: `Your deposit of ${amount} ${asset} has been approved and credited to your wallet.`,
    url: '/wallet',
    tag: 'deposit-approved',
  })
}

export async function notifyUserDepositRejected(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '❌ Deposit Rejected',
    body: `Your deposit request for ${amount} ${asset} was rejected. Please contact support.`,
    url: '/wallet',
    tag: 'deposit-rejected',
  })
}

export async function notifyUserWithdrawApproved(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '✅ Withdrawal Approved',
    body: `Your withdrawal of ${amount} ${asset} has been approved and is being processed.`,
    url: '/wallet',
    tag: 'withdraw-approved',
  })
}

export async function notifyUserWithdrawRejected(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '❌ Withdrawal Rejected',
    body: `Your withdrawal request for ${amount} ${asset} was rejected. Funds have been refunded to your wallet.`,
    url: '/wallet',
    tag: 'withdraw-rejected',
  })
}

export async function notifyUserP2PApproved(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '✅ P2P Order Approved',
    body: `Your P2P order has been approved. ${amount} ${asset} has been credited to your wallet.`,
    url: '/p2p',
    tag: 'p2p-approved',
  })
}

export async function notifyUserP2PRejected(userId: string, amount: number, asset: string) {
  await sendPushToUser(userId, {
    title: '❌ P2P Order Rejected',
    body: `Your P2P order for ${amount} ${asset} was rejected. Please contact support if needed.`,
    url: '/p2p',
    tag: 'p2p-rejected',
  })
}

export async function notifyUserKycApproved(userId: string) {
  await sendPushToUser(userId, {
    title: '✅ KYC Verified',
    body: `Your identity verification has been approved. You now have full access to all features.`,
    url: '/',
    tag: 'kyc-approved',
  })
}

export async function notifyUserKycRejected(userId: string, reason?: string) {
  await sendPushToUser(userId, {
    title: '❌ KYC Rejected',
    body: reason || `Your KYC verification was rejected. Please resubmit with correct documents.`,
    url: '/',
    tag: 'kyc-rejected',
  })
}

export async function notifyUserSupportReply(userId: string, message: string) {
  await sendPushToUser(userId, {
    title: '💬 Support Reply',
    body: message.length > 100 ? message.slice(0, 100) + '...' : message,
    url: '/',
    tag: 'support-reply',
  })
}

export async function notifyUserBroadcast(userIds: string[], title: string, body: string, url = '/') {
  await Promise.all(userIds.map(uid => sendPushToUser(uid, { title, body, url, tag: 'broadcast' })))
}

export function getVapidPublicKey(): string | null {
  return publicKey || null
}
