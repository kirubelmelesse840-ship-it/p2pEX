/**
 * Client-side market data simulation fallback.
 *
 * On Vercel, the WebSocket server (market-service on port 3003) is not available
 * because Vercel doesn't support long-running background processes. This module
 * generates realistic market data (tickers, order books, trades, klines) entirely
 * on the client side, so the exchange UI still feels alive and functional.
 *
 * The simulation is deterministic per symbol (same base prices), but random
 * walk updates make prices move realistically.
 */

'use client'

import { Ticker, OrderBook, MarketTrade, Kline } from './use-market'

// Base prices for all trading pairs (realistic approximate values)
const BASE_PRICES: Record<string, number> = {
  BTC: 67500, ETH: 3450, BNB: 585, SOL: 165, XRP: 0.62, ADA: 0.45,
  DOGE: 0.16, AVAX: 38, LINK: 18.5, DOT: 7.2, MATIC: 0.72, LTC: 85,
  USDT: 1, USDC: 1,
}

const ASSET_NAMES: Record<string, string> = {
  BTC: 'Bitcoin', ETH: 'Ethereum', BNB: 'BNB', SOL: 'Solana', XRP: 'XRP',
  ADA: 'Cardano', DOGE: 'Dogecoin', AVAX: 'Avalanche', LINK: 'Chainlink',
  DOT: 'Polkadot', MATIC: 'Polygon', LTC: 'Litecoin',
  USDT: 'Tether', USDC: 'USD Coin',
}

const PAIRS: Array<[string, string]> = [
  ['BTC', 'USDT'], ['ETH', 'USDT'], ['BNB', 'USDT'], ['SOL', 'USDT'],
  ['XRP', 'USDT'], ['ADA', 'USDT'], ['DOGE', 'USDT'], ['AVAX', 'USDT'],
  ['LINK', 'USDT'], ['DOT', 'USDT'], ['MATIC', 'USDT'], ['LTC', 'USDT'],
  ['BTC', 'USDC'], ['ETH', 'USDC'], ['BTC', 'ETH'], ['ETH', 'BNB'],
]

// State held in module scope (shared across all hook instances)
const tickerMap: Record<string, Ticker> = {}
const orderBookMap: Record<string, OrderBook> = {}
const tradesMap: Record<string, MarketTrade[]> = {}
const klinesMap: Record<string, Kline[]> = {}
let initialized = false
let intervalId: ReturnType<typeof setInterval> | null = null
const subscribers: Array<() => void> = []

function getBasePrice(base: string, quote: string): number {
  const basePrice = BASE_PRICES[base] || 1
  const quotePrice = BASE_PRICES[quote] || 1
  return basePrice / quotePrice
}

function initTickers() {
  if (initialized) return
  initialized = true

  for (const [base, quote] of PAIRS) {
    const symbol = `${base}${quote}`
    const price = getBasePrice(base, quote)
    const changePercent = (Math.random() - 0.5) * 8 // -4% to +4%
    const prevPrice = price / (1 + changePercent / 100)
    tickerMap[symbol] = {
      symbol,
      base,
      quote,
      baseName: ASSET_NAMES[base] || base,
      quoteName: ASSET_NAMES[quote] || quote,
      lastPrice: price,
      prevPrice,
      changePercent,
      high24h: price * (1 + Math.random() * 0.04),
      low24h: price * (1 - Math.random() * 0.04),
      volume24h: Math.random() * 50000 + 5000,
      quoteVolume24h: 0,
    }

    // Initialize order book
    orderBookMap[symbol] = generateOrderBook(price)

    // Initialize klines (60 candles of 1-minute history)
    klinesMap[symbol] = generateKlines(price, 60)

    // Initialize trades
    tradesMap[symbol] = generateTrades(price, 30)
  }

  // Start the simulation loop — update prices every 2 seconds
  intervalId = setInterval(updateAll, 2000)
}

function generateOrderBook(price: number): OrderBook {
  const bids: [number, number][] = []
  const asks: [number, number][] = []
  for (let i = 0; i < 15; i++) {
    const bidPrice = price * (1 - (i + 1) * 0.0003 - Math.random() * 0.0002)
    const askPrice = price * (1 + (i + 1) * 0.0003 + Math.random() * 0.0002)
    const qty = Math.random() * 5 + 0.1
    bids.push([parseFloat(bidPrice.toFixed(6)), parseFloat(qty.toFixed(4))])
    asks.push([parseFloat(askPrice.toFixed(6)), parseFloat(qty.toFixed(4))])
  }
  return { bids, asks }
}

function generateKlines(currentPrice: number, count: number): Kline[] {
  const klines: Kline[] = []
  const now = Date.now()
  let price = currentPrice * (1 - 0.02) // start 2% below current
  for (let i = count; i > 0; i--) {
    const openTime = now - i * 60000
    const open = price
    const volatility = currentPrice * 0.003
    const close = price + (Math.random() - 0.5) * volatility
    const high = Math.max(open, close) + Math.random() * volatility * 0.5
    const low = Math.min(open, close) - Math.random() * volatility * 0.5
    const volume = Math.random() * 100 + 10
    klines.push({
      openTime,
      open: parseFloat(open.toFixed(6)),
      high: parseFloat(high.toFixed(6)),
      low: parseFloat(low.toFixed(6)),
      close: parseFloat(close.toFixed(6)),
      volume: parseFloat(volume.toFixed(4)),
      closeTime: openTime + 59999,
    })
    price = close
  }
  // Set the last candle's close to the current price
  if (klines.length > 0) {
    klines[klines.length - 1].close = parseFloat(currentPrice.toFixed(6))
  }
  return klines
}

function generateTrades(price: number, count: number): MarketTrade[] {
  const trades: MarketTrade[] = []
  const now = Date.now()
  for (let i = 0; i < count; i++) {
    const tradePrice = price * (1 + (Math.random() - 0.5) * 0.001)
    trades.push({
      id: `sim-${now}-${i}`,
      price: parseFloat(tradePrice.toFixed(6)),
      qty: parseFloat((Math.random() * 2 + 0.01).toFixed(4)),
      time: now - i * 5000,
      isBuyerMaker: Math.random() > 0.5,
    })
  }
  return trades
}

function updateAll() {
  for (const [base, quote] of PAIRS) {
    const symbol = `${base}${quote}`
    const ticker = tickerMap[symbol]
    if (!ticker) continue

    // Random walk price update
    const volatility = ticker.lastPrice * 0.0015 // 0.15% per tick
    const delta = (Math.random() - 0.5) * volatility * 2
    const newPrice = Math.max(ticker.lastPrice + delta, ticker.lastPrice * 0.5)

    // Update ticker
    ticker.prevPrice = ticker.lastPrice
    ticker.lastPrice = parseFloat(newPrice.toFixed(6))
    ticker.changePercent = ((newPrice - (ticker.prevPrice || newPrice)) / (ticker.prevPrice || newPrice)) * 100 + ticker.changePercent * 0.99
    ticker.high24h = Math.max(ticker.high24h, newPrice)
    ticker.low24h = Math.min(ticker.low24h, newPrice)
    ticker.volume24h += Math.random() * 10

    // Update order book occasionally
    if (Math.random() > 0.5) {
      orderBookMap[symbol] = generateOrderBook(newPrice)
    }

    // Add a new trade
    const newTrade: MarketTrade = {
      id: `sim-${Date.now()}-${Math.random()}`,
      price: parseFloat(newPrice.toFixed(6)),
      qty: parseFloat((Math.random() * 2 + 0.01).toFixed(4)),
      time: Date.now(),
      isBuyerMaker: Math.random() > 0.5,
    }
    tradesMap[symbol] = [newTrade, ...(tradesMap[symbol] || [])].slice(0, 50)

    // Update klines (update last candle, add new one if minute changed)
    const klines = klinesMap[symbol] || []
    if (klines.length > 0) {
      const last = klines[klines.length - 1]
      const minute = Math.floor(Date.now() / 60000)
      const lastMinute = Math.floor(last.openTime / 60000)
      if (minute > lastMinute) {
        // Add new candle
        klines.push({
          openTime: minute * 60000,
          open: last.close,
          high: Math.max(last.close, newPrice),
          low: Math.min(last.close, newPrice),
          close: parseFloat(newPrice.toFixed(6)),
          volume: Math.random() * 100,
          closeTime: minute * 60000 + 59999,
        })
        if (klines.length > 200) klines.shift()
      } else {
        // Update current candle
        last.close = parseFloat(newPrice.toFixed(6))
        last.high = Math.max(last.high, newPrice)
        last.low = Math.min(last.low, newPrice)
        last.volume += Math.random() * 5
      }
    }
  }

  // Notify all subscribers
  for (const cb of subscribers) cb()
}

function subscribe(cb: () => void): () => void {
  subscribers.push(cb)
  return () => {
    const idx = subscribers.indexOf(cb)
    if (idx >= 0) subscribers.splice(idx, 1)
  }
}

function getAllTickers(): Ticker[] {
  return Object.values(tickerMap)
}

function getTicker(symbol: string): Ticker | null {
  return tickerMap[symbol.toUpperCase()] || null
}

function getOrderBook(symbol: string): OrderBook {
  return orderBookMap[symbol.toUpperCase()] || { bids: [], asks: [] }
}

function getTrades(symbol: string): MarketTrade[] {
  return tradesMap[symbol.toUpperCase()] || []
}

function getKlines(symbol: string): Kline[] {
  return klinesMap[symbol.toUpperCase()] || []
}

export {
  initTickers,
  subscribe,
  getAllTickers,
  getTicker,
  getOrderBook,
  getTrades,
  getKlines,
}
