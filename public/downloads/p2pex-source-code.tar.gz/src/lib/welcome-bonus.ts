/**
 * Welcome bonus helper — credits 10 USDT to a new user's wallet and sends them
 * an in-app notification + push notification.
 */
import { db } from '@/lib/db'

const WELCOME_BONUS_AMOUNT = 10
const WELCOME_BONUS_ASSET = 'USDT'

export async function creditWelcomeBonus(userId: string): Promise<void> {
  try {
    let wallet = await db.wallet.findUnique({
      where: { userId_asset: { userId, asset: WELCOME_BONUS_ASSET } },
    })
    if (!wallet) {
      wallet = await db.wallet.create({
        data: {
          userId, asset: WELCOME_BONUS_ASSET, assetName: 'Tether',
          balance: 0, available: 0, locked: 0,
          depositAddress: 'T' + Math.random().toString(36).slice(2, 34).toUpperCase(),
        },
      })
    }
    await db.wallet.update({
      where: { id: wallet.id },
      data: {
        balance: { increment: WELCOME_BONUS_AMOUNT },
        available: { increment: WELCOME_BONUS_AMOUNT },
      },
    })
    await db.transaction.create({
      data: {
        userId, asset: WELCOME_BONUS_ASSET, type: 'DEPOSIT',
        amount: WELCOME_BONUS_AMOUNT, fee: 0, network: 'WELCOME_BONUS',
        fromAddress: 'P2PEX Welcome Bonus', toAddress: 'internal',
        txHash: 'welcome-' + userId.slice(-8),
        status: 'COMPLETED', confirmations: 1, requiredConfirmations: 1,
        note: `Welcome bonus — ${WELCOME_BONUS_AMOUNT} USDT credited to your wallet`,
      },
    })
    await db.adminNotification.create({
      data: {
        userId,
        title: '🎁 Welcome Bonus Received!',
        message: `You have received the welcome bonus of ${WELCOME_BONUS_AMOUNT} USDT. It has been credited to your wallet. Start trading on P2PEX now!`,
        type: 'success', isRead: false,
      },
    })
    try {
      const { sendPushToUser } = await import('@/lib/push')
      sendPushToUser(userId, {
        title: '🎁 Welcome Bonus Received!',
        body: `You have received the welcome bonus of ${WELCOME_BONUS_AMOUNT} USDT. It has been credited to your wallet.`,
        url: '/wallet', tag: 'welcome-bonus',
      }).catch((e) => console.error('[welcome-bonus] push error:', e))
    } catch (e) {
      console.error('[welcome-bonus] failed to load push lib:', e)
    }
    console.log(`[welcome-bonus] Credited ${WELCOME_BONUS_AMOUNT} USDT to user ${userId}`)
  } catch (e: any) {
    console.error('[welcome-bonus] Failed to credit welcome bonus:', e?.message || e)
  }
}
