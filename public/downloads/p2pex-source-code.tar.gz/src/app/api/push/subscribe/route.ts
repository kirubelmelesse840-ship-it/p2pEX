/**
 * POST /api/push/subscribe - register a push subscription for the current user
 * DELETE /api/push/subscribe - unregister a push subscription
 * GET /api/push/subscribe - returns the VAPID public key + whether user is subscribed
 */
import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { getVapidPublicKey } from '@/lib/push'

export async function GET(req: NextRequest) {
  const publicKey = getVapidPublicKey()
  if (!publicKey) {
    return NextResponse.json({ error: 'Push notifications not configured' }, { status: 500 })
  }
  const user = await getCurrentUser(req as unknown as Request)
  if (!user) {
    return NextResponse.json({ publicKey, subscribed: false })
  }
  const count = await db.pushSubscription.count({ where: { userId: user.id } })
  return NextResponse.json({ publicKey, subscribed: count > 0, subscriptionCount: count })
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser(req as unknown as Request)
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    const { endpoint, keys } = await req.json()
    if (!endpoint || !keys?.p256dh || !keys?.auth) {
      return NextResponse.json({ error: 'Invalid subscription payload' }, { status: 400 })
    }
    const userAgent = req.headers.get('user-agent') || undefined
    await db.pushSubscription.upsert({
      where: { endpoint },
      create: { userId: user.id, endpoint, p256dh: keys.p256dh, auth: keys.auth, userAgent },
      update: { userId: user.id, p256dh: keys.p256dh, auth: keys.auth, userAgent, updatedAt: new Date() },
    })
    console.log(`[push] Subscription saved for user ${user.id} (${user.email})`)
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    console.error('[push/subscribe POST]', e)
    return NextResponse.json({ error: e.message || 'Internal error' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await getCurrentUser(req as unknown as Request)
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    const { endpoint } = await req.json()
    if (!endpoint) return NextResponse.json({ error: 'endpoint required' }, { status: 400 })
    await db.pushSubscription.deleteMany({ where: { userId: user.id, endpoint } })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    console.error('[push/subscribe DELETE]', e)
    return NextResponse.json({ error: e.message || 'Internal error' }, { status: 500 })
  }
}
