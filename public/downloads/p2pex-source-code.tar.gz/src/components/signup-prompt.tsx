'use client'

/**
 * SignupPrompt — a reusable signup/login card shown to non-authenticated users.
 * Used on Markets, Trade, P2P, and Wallet pages when the user is not logged in.
 *
 * Dispatches the 'open-auth' custom event which the navbar's AuthButtons
 * component listens for to open the login/signup dialog.
 */

import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import { BackButton } from '@/components/back-button'

interface SignupPromptProps {
  /** Page-specific icon */
  icon: React.ReactNode
  /** Page-specific title, e.g. "Sign in to Trade" */
  title: string
  /** Page-specific description */
  description: string
  /** Optional feature badges to show below the buttons */
  features?: Array<{ icon: React.ReactNode; label: string }>
  /** Back button destination (defaults to 'home') */
  backTo?: 'home' | 'markets'
}

export function SignupPrompt({ icon, title, description, features, backTo = 'home' }: SignupPromptProps) {
  const setView = useAppStore(s => s.setView)

  const openAuth = (mode: 'signup' | 'login') => {
    window.dispatchEvent(new CustomEvent('open-auth', { detail: mode }))
  }

  return (
    <div className="container mx-auto px-4 py-4 max-w-6xl">
      <BackButton to={backTo} />
      <div className="max-w-md mx-auto py-8 text-center">
        <div className="flex h-20 w-20 mx-auto items-center justify-center rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 text-white mb-4">
          {icon}
        </div>
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-sm text-muted-foreground mb-6" dangerouslySetInnerHTML={{ __html: description }} />
        <div className="space-y-2">
          <Button
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white"
            onClick={() => openAuth('signup')}
          >
            Create Account
          </Button>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => openAuth('login')}
          >
            Log In
          </Button>
        </div>
        {features && features.length > 0 && (
          <div className="mt-6 grid gap-2 text-xs text-muted-foreground" style={{ gridTemplateColumns: `repeat(${features.length}, minmax(0, 1fr))` }}>
            {features.map((f, i) => (
              <div key={i} className="p-2 bg-muted/30 rounded-lg">
                <div className="flex justify-center mb-1 text-primary">{f.icon}</div>
                <p>{f.label}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
