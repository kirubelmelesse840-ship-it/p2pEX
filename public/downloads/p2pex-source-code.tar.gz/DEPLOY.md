# P2PEX Deployment Guide — Vercel + Supabase

This guide walks you through deploying P2PEX to Vercel with a Supabase PostgreSQL database.

---

## Prerequisites

1. A [Vercel](https://vercel.com) account
2. A [Supabase](https://supabase.com) account
3. [Node.js](https://nodejs.org) 18+ installed
4. The P2PEX codebase (this repository)

---

## Step 1: Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in
2. Click **New Project**
3. Fill in:
   - **Name**: `p2pex`
   - **Database Password**: Choose a strong password (save it!)
   - **Region**: Choose the closest region to your users
4. Click **Create new project**
5. Wait ~2 minutes for the project to be ready

---

## Step 2: Get Your Database Connection Strings

1. In your Supabase dashboard, go to **Project Settings** → **Database**
2. Under **Connection string**, you'll see two URLs:

### For `DATABASE_URL` (pooled connection — used by the app):
```
postgresql://postgres.[PROJECT-REF]:[YOUR-PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true
```

### For `DIRECT_URL` (direct connection — used for migrations):
```
postgresql://postgres.[PROJECT-REF]:[YOUR-PASSWORD]@aws-0-[REGION].supabase.com:5432/postgres
```

> Replace `[YOUR-PASSWORD]` with the password you set in Step 1.

---

## Step 3: Set Up Environment Variables Locally

Update your `.env` file with the Supabase URLs:

```env
# Supabase Database
DATABASE_URL="postgresql://postgres.[REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true"
DIRECT_URL="postgresql://postgres.[REF]:[PASSWORD]@aws-0-[REGION].supabase.com:5432/postgres"

# VAPID keys (generate new ones with: npx web-push generate-vapid-keys)
VAPID_PUBLIC_KEY="your-public-key"
VAPID_PRIVATE_KEY="your-private-key"
VAPID_SUBJECT="mailto:supportp2pex.exchange@gmail.com"

# Admin email
ADMIN_EMAIL="kirubelmelesse840@gmail.com"
```

---

## Step 4: Push the Database Schema to Supabase

Run these commands locally:

```bash
# Generate Prisma client
npx prisma generate

# Push the schema to Supabase (creates all tables)
npx prisma db push
```

---

## Step 5: Sign Up the Admin Account

1. Run the dev server locally:
   ```bash
   npm run dev
   ```
2. Open `http://localhost:3000`
3. Click **Sign Up** and register with your admin email:
   - Email: `kirubelmelesse840@gmail.com`
   - Password: (choose a strong password)
4. This creates your admin user and credits the 10 USDT welcome bonus

---

## Step 6: Seed the Database

Run the seed script to create trading pairs, mark the admin, and create P2P listings:

```bash
npx tsx scripts/seed-supabase.ts
```

This will:
- Create 14 trading pairs (BTC/USDT, ETH/USDT, etc.)
- Set your account as admin
- Create 7 P2P ads (4 buy + 3 sell)

---

## Step 7: Deploy to Vercel

### Option A: Via Vercel Dashboard

1. Push your code to GitHub/GitLab/Bitbucket
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your repository
4. Vercel will auto-detect Next.js — keep the default settings
5. Under **Environment Variables**, add ALL of these:

| Name | Value |
|------|-------|
| `DATABASE_URL` | `postgresql://postgres.[REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true` |
| `DIRECT_URL` | `postgresql://postgres.[REF]:[PASSWORD]@aws-0-[REGION].supabase.com:5432/postgres` |
| `VAPID_PUBLIC_KEY` | (your VAPID public key) |
| `VAPID_PRIVATE_KEY` | (your VAPID private key) |
| `VAPID_SUBJECT` | `mailto:supportp2pex.exchange@gmail.com` |
| `ADMIN_EMAIL` | `kirubelmelesse840@gmail.com` |

6. Click **Deploy**
7. Wait ~3-5 minutes for the build to complete

### Option B: Via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Follow the prompts, then add environment variables:
vercel env add DATABASE_URL
vercel env add DIRECT_URL
vercel env add VAPID_PUBLIC_KEY
vercel env add VAPID_PRIVATE_KEY
vercel env add VAPID_SUBJECT
vercel env add ADMIN_EMAIL

# Redeploy with env vars
vercel --prod
```

---

## Step 8: Verify Your Deployment

1. Visit your Vercel URL (e.g., `https://p2pex.vercel.app`)
2. Sign up for a new account — you should get 10 USDT welcome bonus
3. Check the P2P page — you should see 7 ads
4. Check the Markets page — prices should be moving (client-side simulation)
5. Check the Wallet page — try depositing/withdrawing

---

## Important Notes

### WebSocket / Market Data
- The WebSocket market data server (port 3003) **does not run on Vercel** (Vercel doesn't support long-running background processes)
- The app automatically falls back to **client-side price simulation** in production
- Prices update every 2 seconds with realistic random-walk movements
- All charts, order books, and trade feeds work with simulated data

### Database
- Supabase provides a managed PostgreSQL database
- The Prisma schema uses `postgresql` as the provider
- Connection pooling (port 6543) is used for serverless compatibility
- Direct connection (port 5432) is used for migrations

### File Storage
- KYC documents and payment screenshots are stored as base64 in the database
- This works on Vercel (no filesystem needed)
- For large-scale use, consider migrating to Supabase Storage

### Push Notifications
- Web push notifications work on Vercel
- VAPID keys are required (set as environment variables)
- The service worker (`/public/sw.js`) is served as a static file

### Environment Variables
- ALL environment variables must be set in Vercel's dashboard
- The `.env` file is only used locally — Vercel doesn't read it

---

## Troubleshooting

### "Prisma can't reach database"
- Check that `DATABASE_URL` and `DIRECT_URL` are set correctly in Vercel
- Make sure the Supabase project is not paused (free tier pauses after 7 days of inactivity)
- Verify the password is correct (no special characters that need URL encoding)

### "Function execution timed out"
- Vercel serverless functions have a 10-30 second timeout
- The `vercel.json` sets `maxDuration: 30` for API routes
- If you need longer timeouts, upgrade to Vercel Pro

### Build fails with "prisma generate"
- The `postinstall` script in `package.json` runs `prisma generate` automatically
- Make sure `vercel.json` has `"buildCommand": "prisma generate && next build"`

### Push notifications not working
- Make sure VAPID keys are set as environment variables in Vercel
- Check that the service worker is accessible at `/sw.js`
- iOS Safari requires the site to be added to Home Screen first

---

## Quick Commands Reference

```bash
# Local development
npm run dev

# Push schema changes to Supabase
npx prisma db push

# Generate Prisma client
npx prisma generate

# Run database seed
npx tsx scripts/seed-supabase.ts

# Deploy to Vercel
vercel --prod

# View Vercel logs
vercel logs
```

---

Your P2PEX exchange is now live on Vercel + Supabase! 🚀
